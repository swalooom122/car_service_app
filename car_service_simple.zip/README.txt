مشروع بسيط لتطبيق مركز صيانة سيارات (واجهه عربية)
يشمل: العملاء - الفواتير - المصروفات - التقرير الشهري.
لتشغيل: افتح المشروع في Android Studio -> flutter pub get -> flutter run
لبناء APK: flutter build apk --release
