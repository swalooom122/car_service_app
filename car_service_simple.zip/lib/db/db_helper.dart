import 'dart:async';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static Database? _db;
  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDB();
    return _db!;
  }

  Future<Database> initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, 'car_service.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  FutureOr<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE Customers (
        CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT NOT NULL,
        Phone TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE Cars (
        CarID INTEGER PRIMARY KEY AUTOINCREMENT,
        CustomerID INTEGER,
        PlateNumber TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE Invoices (
        InvoiceID INTEGER PRIMARY KEY AUTOINCREMENT,
        InvoiceDate TEXT,
        TotalAmount REAL,
        Paid INTEGER DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE Expenses (
        ExpenseID INTEGER PRIMARY KEY AUTOINCREMENT,
        ExpenseDate TEXT,
        Amount REAL
      )
    ''');
  }

  // simple CRUD examples
  Future<int> insertCustomer(Map<String, dynamic> row) async {
    final database = await db;
    return await database.insert('Customers', row);
  }
  Future<List<Map<String, dynamic>>> getAllCustomers() async {
    final database = await db;
    return await database.query('Customers', orderBy: 'Name');
  }
  Future<int> insertInvoice(Map<String, dynamic> row) async {
    final database = await db;
    return await database.insert('Invoices', row);
  }
  Future<List<Map<String, dynamic>>> getInvoicesByMonth(int month, int year) async {
    final m = month.toString().padLeft(2,'0');
    final y = year.toString();
    final database = await db;
    return await database.rawQuery('''
      SELECT * FROM Invoices WHERE strftime('%m', InvoiceDate)=? AND strftime('%Y', InvoiceDate)=?
    ''', [m,y]);
  }
  Future<double> monthlyRevenue(int month, int year) async {
    final database = await db;
    final m = month.toString().padLeft(2,'0');
    final y = year.toString();
    final result = await database.rawQuery('''
      SELECT SUM(TotalAmount) as total FROM Invoices WHERE strftime('%m', InvoiceDate)=? AND strftime('%Y', InvoiceDate)=? AND Paid=1
    ''', [m,y]);
    return result.first['total'] != null ? (result.first['total'] as num).toDouble() : 0.0;
  }
  Future<int> insertExpense(Map<String, dynamic> row) async {
    final database = await db;
    return await database.insert('Expenses', row);
  }
  Future<double> monthlyExpenses(int month, int year) async {
    final database = await db;
    final m = month.toString().padLeft(2,'0');
    final y = year.toString();
    final database = await db;
    final result = await database.rawQuery('''
      SELECT SUM(Amount) as total FROM Expenses WHERE strftime('%m', ExpenseDate)=? AND strftime('%Y', ExpenseDate)=?
    ''', [m,y]);
    return result.first['total'] != null ? (result.first['total'] as num).toDouble() : 0.0;
  }
}
