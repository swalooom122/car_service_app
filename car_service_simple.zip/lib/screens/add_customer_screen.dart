import 'package:flutter/material.dart';
import '../db/db_helper.dart';

class AddCustomerScreen extends StatefulWidget { @override _AddCustomerScreenState createState() => _AddCustomerScreenState(); }
class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final db = DBHelper();
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('إضافة عميل')),
        body: Padding(padding: EdgeInsets.all(16), child: Form(key: _formKey, child: Column(children: [
          TextFormField(controller: _name, decoration: InputDecoration(labelText: 'الاسم'), validator: (v)=>v==null||v.isEmpty? 'ادخل الاسم':null),
          TextFormField(controller: _phone, decoration: InputDecoration(labelText: 'الهاتف')),
          SizedBox(height:12),
          ElevatedButton(child: Text('حفظ'), onPressed: () async { if(_formKey.currentState!.validate()){ await db.insertCustomer({'Name': _name.text, 'Phone': _phone.text}); Navigator.pop(context);} })
        ])),
      ),
    );
  }
}
