import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import 'package:intl/intl.dart';

class AddInvoiceScreen extends StatefulWidget { @override _AddInvoiceScreenState createState() => _AddInvoiceScreenState(); }
class _AddInvoiceScreenState extends State<AddInvoiceScreen> {
  final _form = GlobalKey<FormState>();
  final _amount = TextEditingController();
  bool _paid = true;
  final db = DBHelper();
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('إضافة فاتورة')),
        body: Padding(padding: EdgeInsets.all(16), child: Form(key: _form, child: Column(children: [
          TextFormField(controller: _amount, decoration: InputDecoration(labelText: 'المبلغ'), keyboardType: TextInputType.number, validator: (v)=>v==null||v.isEmpty? 'ادخل المبلغ':null),
          CheckboxListTile(title: Text('تم الدفع'), value: _paid, onChanged: (v)=> setState(()=> _paid = v ?? true)),
          SizedBox(height:12),
          ElevatedButton(child: Text('حفظ'), onPressed: () async { if(_form.currentState!.validate()){ final now = DateTime.now().toIso8601String().split('T').first; await db.insertInvoice({'InvoiceDate': now, 'TotalAmount': double.tryParse(_amount.text) ?? 0.0, 'Paid': _paid ? 1 : 0}); Navigator.pop(context);} })
        ])),
      ),
    );
  }
}
