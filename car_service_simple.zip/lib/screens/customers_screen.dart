import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import 'add_customer_screen.dart';

class CustomersScreen extends StatefulWidget { @override _CustomersScreenState createState() => _CustomersScreenState(); }

class _CustomersScreenState extends State<CustomersScreen> {
  final db = DBHelper();
  List<Map<String,dynamic>> customers = [];
  @override void initState(){ super.initState(); load(); }
  void load() async { final list = await db.getAllCustomers(); setState(()=>customers = list); }
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('العملاء')),
        body: ListView.builder(itemCount: customers.length, itemBuilder: (c,i){
          final item = customers[i];
          return ListTile(title: Text(item['Name'] ?? ''), subtitle: Text(item['Phone'] ?? ''));
        }),
        floatingActionButton: FloatingActionButton(child: Icon(Icons.add), onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => AddCustomerScreen())); load(); }),
      ),
    );
  }
}
