import 'package:flutter/material.dart';
import '../db/db_helper.dart';

class ExpensesScreen extends StatefulWidget { @override _ExpensesScreenState createState() => _ExpensesScreenState(); }
class _ExpensesScreenState extends State<ExpensesScreen> {
  final db = DBHelper();
  final _cat = TextEditingController();
  final _amount = TextEditingController();
  List<Map<String,dynamic>> expenses = [];
  @override void initState(){ super.initState(); load(); }
  void load() async { final database = await db.db; final list = await database.query('Expenses', orderBy: 'ExpenseDate DESC'); setState(()=>expenses = list); }
  void add() async { if(_cat.text.isNotEmpty && _amount.text.isNotEmpty){ final now = DateTime.now().toIso8601String().split('T').first; await db.insertExpense({'ExpenseDate': now, 'Amount': double.tryParse(_amount.text) ?? 0.0}); _cat.clear(); _amount.clear(); load(); } }
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('المصروفات')),
        body: Padding(padding: EdgeInsets.all(12), child: Column(children: [
          TextField(controller: _cat, decoration: InputDecoration(labelText: 'النوع')),
          TextField(controller: _amount, decoration: InputDecoration(labelText: 'المبلغ'), keyboardType: TextInputType.number),
          SizedBox(height:8),
          ElevatedButton(child: Text('إضافة'), onPressed: add),
          SizedBox(height:12),
          Expanded(child: ListView.builder(itemCount: expenses.length, itemBuilder: (c,i){ final e = expenses[i]; return ListTile(title: Text('\${e['Amount'] ?? 0}'), subtitle: Text(e['ExpenseDate'] ?? '')); }))
        ])),
      ),
    );
  }
}
