import 'package:flutter/material.dart';
import 'customers_screen.dart';
import 'invoices_screen.dart';
import 'expenses_screen.dart';
import 'report_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('نظام مركز الصيانة')),
        body: Padding(padding: EdgeInsets.all(16), child: Column(children: [
          ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CustomersScreen())), child: Text('العملاء')),
          SizedBox(height:8),
          ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => InvoicesScreen())), child: Text('الفواتير')),
          SizedBox(height:8),
          ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExpensesScreen())), child: Text('المصروفات')),
          SizedBox(height:8),
          ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportScreen())), child: Text('التقرير الشهري')),
        ])),
      ),
    );
  }
}
