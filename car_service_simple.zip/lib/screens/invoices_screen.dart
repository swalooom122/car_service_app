import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import 'add_invoice_screen.dart';

class InvoicesScreen extends StatefulWidget { @override _InvoicesScreenState createState() => _InvoicesScreenState(); }
class _InvoicesScreenState extends State<InvoicesScreen> {
  final db = DBHelper();
  List<Map<String,dynamic>> invoices = [];
  @override void initState(){ super.initState(); load(); }
  void load() async { final database = await db.db; final list = await database.query('Invoices', orderBy: 'InvoiceDate DESC'); setState(()=>invoices = list); }
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('الفواتير')),
        body: ListView.builder(itemCount: invoices.length, itemBuilder: (c,i){
          final inv = invoices[i];
          return ListTile(title: Text('فاتورة \${inv['InvoiceID']}'), subtitle: Text('\${inv['TotalAmount'] ?? 0} - \${inv['InvoiceDate'] ?? ''}'));
        }),
        floatingActionButton: FloatingActionButton(child: Icon(Icons.add), onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => AddInvoiceScreen())); load(); }),
      ),
    );
  }
}
