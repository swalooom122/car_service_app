import 'package:flutter/material.dart';
import '../db/db_helper.dart';

class ReportScreen extends StatefulWidget { @override _ReportScreenState createState() => _ReportScreenState(); }
class _ReportScreenState extends State<ReportScreen> {
  final db = DBHelper();
  int _month = DateTime.now().month;
  int _year = DateTime.now().year;
  double _rev = 0.0;
  double _exp = 0.0;
  @override void initState(){ super.initState(); load(); }
  void load() async { final r = await db.monthlyRevenue(_month, _year); final e = await db.monthlyExpenses(_month, _year); setState(()=>{ _rev = r; _exp = e }); }
  @override Widget build(BuildContext context){
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(appBar: AppBar(title: Text('التقرير الشهري')),
        body: Padding(padding: EdgeInsets.all(16), child: Column(children: [
          Row(children: [ Expanded(child: Text('الشهر:')), Expanded(child: DropdownButton<int>(value: _month, items: List.generate(12, (i)=>i+1).map((m)=>DropdownMenuItem(value:m, child:Text(m.toString()))).toList(), onChanged: (v){ setState(()=> _month = v!); load(); })), Expanded(child: Text('السنة:')), Expanded(child: DropdownButton<int>(value: _year, items: List.generate(5, (i)=>DateTime.now().year - i).map((y)=>DropdownMenuItem(value:y, child:Text(y.toString()))).toList(), onChanged: (v){ setState(()=> _year = v!); load(); })), ]),
          SizedBox(height:20),
          Card(child: ListTile(title: Text('إجمالي الإيرادات'), trailing: Text(_rev.toStringAsFixed(2)))),
          Card(child: ListTile(title: Text('إجمالي المصروفات'), trailing: Text(_exp.toStringAsFixed(2)))),
          Card(child: ListTile(title: Text('صافي الربح'), trailing: Text((_rev - _exp).toStringAsFixed(2)))),
        ])),
      ),
    );
  }
}
